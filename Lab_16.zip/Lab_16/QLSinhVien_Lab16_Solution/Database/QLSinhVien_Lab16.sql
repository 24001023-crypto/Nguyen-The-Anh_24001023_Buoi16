USE master;
GO

IF DB_ID('QLSinhVien_Lab16') IS NULL
    CREATE DATABASE QLSinhVien_Lab16;
GO

USE QLSinhVien_Lab16;
GO

-- 1. Xóa bảng cũ theo thứ tự khóa ngoại nếu chạy lại
IF OBJECT_ID('dbo.DangKy', 'U') IS NOT NULL DROP TABLE dbo.DangKy;
IF OBJECT_ID('dbo.SinhVien', 'U') IS NOT NULL DROP TABLE dbo.SinhVien;
IF OBJECT_ID('dbo.HocPhan', 'U') IS NOT NULL DROP TABLE dbo.HocPhan;
IF OBJECT_ID('dbo.Khoa', 'U') IS NOT NULL DROP TABLE dbo.Khoa;
GO

-- 2. Tạo bảng & Ràng buộc
CREATE TABLE Khoa (
    MaKhoa VARCHAR(10) PRIMARY KEY,
    TenKhoa NVARCHAR(100) NOT NULL,
    DienThoai VARCHAR(15) NULL
);

CREATE TABLE SinhVien (
    MaSV VARCHAR(15) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE NOT NULL,
    GioiTinh NVARCHAR(10) CHECK (GioiTinh IN (N'Nam', N'Nữ', N'Khác')),
    Email VARCHAR(100) UNIQUE,
    MaKhoa VARCHAR(10) NOT NULL FOREIGN KEY REFERENCES Khoa(MaKhoa)
);

CREATE TABLE HocPhan (
    MaHP VARCHAR(15) PRIMARY KEY,
    TenHP NVARCHAR(100) NOT NULL,
    SoTinChi INT CHECK (SoTinChi BETWEEN 1 AND 10),
    HocPhiTinChi DECIMAL(18, 0) DEFAULT 450000
);

CREATE TABLE DangKy (
    MaSV VARCHAR(15) NOT NULL FOREIGN KEY REFERENCES SinhVien(MaSV),
    MaHP VARCHAR(15) NOT NULL FOREIGN KEY REFERENCES HocPhan(MaHP),
    HocKy VARCHAR(10) NOT NULL,
    DiemTongKet FLOAT NULL CHECK (DiemTongKet BETWEEN 0 AND 10),
    NgayDangKy DATETIME DEFAULT GETDATE(),
    PRIMARY KEY (MaSV, MaHP, HocKy)
);
GO

-- 3. Tạo Index tối ưu tìm kiếm
CREATE INDEX IX_SinhVien_HoTen ON SinhVien(HoTen);
CREATE INDEX IX_SinhVien_MaKhoa ON SinhVien(MaKhoa);
GO

-- 4. Tạo View phục vụ Crystal Reports
CREATE OR ALTER VIEW vw_BaoCaoSinhVien AS
SELECT 
    sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.Email,
    k.MaKhoa, k.TenKhoa,
    COUNT(dk.MaHP) AS TongSoMon,
    ISNULL(SUM(hp.SoTinChi), 0) AS TongTinChi,
    ISNULL(SUM(hp.SoTinChi * hp.HocPhiTinChi), 0) AS TongHocPhi
FROM SinhVien sv
INNER JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
LEFT JOIN DangKy dk ON sv.MaSV = dk.MaSV
LEFT JOIN HocPhan hp ON dk.MaHP = hp.MaHP
GROUP BY sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.Email, k.MaKhoa, k.TenKhoa;
GO

CREATE OR ALTER VIEW vw_BangDiemChiTiet AS
SELECT 
    sv.MaSV, sv.HoTen, k.TenKhoa,
    hp.MaHP, hp.TenHP, hp.SoTinChi, dk.HocKy, dk.DiemTongKet
FROM DangKy dk
INNER JOIN SinhVien sv ON dk.MaSV = sv.MaSV
INNER JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
INNER JOIN HocPhan hp ON dk.MaHP = hp.MaHP;
GO

-- 5. Stored Procedures CRUD & Tìm kiếm đa tiêu chí + Phân trang
CREATE OR ALTER PROCEDURE sp_SinhVien_Search
    @Keyword NVARCHAR(100) = NULL,
    @MaKhoa VARCHAR(10) = NULL,
    @PageIndex INT = 1,
    @PageSize INT = 20
AS
BEGIN
    SET NOCOUNT ON;
    SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.Email, sv.MaKhoa, k.TenKhoa,
           COUNT(*) OVER() AS TotalRecords
    FROM SinhVien sv
    INNER JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
    WHERE (@Keyword IS NULL OR @Keyword = '' OR sv.MaSV LIKE '%' + @Keyword + '%' OR sv.HoTen LIKE N'%' + @Keyword + '%')
      AND (@MaKhoa IS NULL OR @MaKhoa = '' OR sv.MaKhoa = @MaKhoa)
    ORDER BY sv.MaSV ASC
    OFFSET (@PageIndex - 1) * @PageSize ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE sp_SinhVien_Insert
    @MaSV VARCHAR(15), @HoTen NVARCHAR(100), @NgaySinh DATE,
    @GioiTinh NVARCHAR(10), @Email VARCHAR(100), @MaKhoa VARCHAR(10)
AS
BEGIN
    INSERT INTO SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, Email, MaKhoa)
    VALUES (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @Email, @MaKhoa);
END;
GO

CREATE OR ALTER PROCEDURE sp_SinhVien_Update
    @MaSV VARCHAR(15), @HoTen NVARCHAR(100), @NgaySinh DATE,
    @GioiTinh NVARCHAR(10), @Email VARCHAR(100), @MaKhoa VARCHAR(10)
AS
BEGIN
    UPDATE SinhVien
    SET HoTen = @HoTen, NgaySinh = @NgaySinh, GioiTinh = @GioiTinh, Email = @Email, MaKhoa = @MaKhoa
    WHERE MaSV = @MaSV;
END;
GO

CREATE OR ALTER PROCEDURE sp_SinhVien_Delete
    @MaSV VARCHAR(15)
AS
BEGIN
    DELETE FROM SinhVien WHERE MaSV = @MaSV;
END;
GO

-- 6. Dữ liệu mẫu
INSERT INTO Khoa VALUES 
('CNTT', N'Công nghệ Thông tin', '0243888111'),
('KT', N'Kinh tế & Quản trị', '0243888222'),
('NN', N'Ngôn ngữ Anh', '0243888333');

INSERT INTO HocPhan VALUES
('IT3212', N'Lập trình .NET', 3, 450000),
('IT3011', N'Cơ sở dữ liệu', 3, 450000),
('IT3080', N'Mạng máy tính', 3, 450000),
('KT1010', N'Kinh tế vi mô', 2, 400000);

INSERT INTO SinhVien VALUES
('SV001', N'Nguyễn Minh Thành', '2006-02-24', N'Nam', 'thanhnm@eaut.edu.vn', 'CNTT'),
('SV002', N'Trần Thị Thu Hà', '2006-05-12', N'Nữ', 'hattt@eaut.edu.vn', 'CNTT'),
('SV003', N'Lê Hoàng Nam', '2005-11-20', N'Nam', 'namlh@eaut.edu.vn', 'KT'),
('SV004', N'Phạm Ngọc Ánh', '2006-08-15', N'Nữ', 'anhpn@eaut.edu.vn', 'NN'),
('SV005', N'Đỗ Quang Minh', '2006-01-30', N'Nam', 'minhdq@eaut.edu.vn', 'CNTT');

INSERT INTO DangKy (MaSV, MaHP, HocKy, DiemTongKet) VALUES
('SV001', 'IT3212', '2026-1', 9.0),
('SV001', 'IT3011', '2026-1', 8.5),
('SV002', 'IT3212', '2026-1', 8.0),
('SV003', 'KT1010', '2026-1', 7.5);
GO
