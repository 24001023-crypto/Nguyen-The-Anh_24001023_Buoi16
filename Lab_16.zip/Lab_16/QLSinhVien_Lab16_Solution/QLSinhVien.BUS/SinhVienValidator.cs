﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using QLSinhVien.DTO;

namespace QLSinhVien.BUS
{
    public class ValidationResult
    {
        public bool IsValid => Errors.Count == 0;
        public List<string> Errors { get; } = new List<string>();
    }

    public static class SinhVienValidator
    {
        public static ValidationResult Validate(SinhVienDTO sv)
        {
            var result = new ValidationResult();
            if (string.IsNullOrWhiteSpace(sv.MaSV))
                result.Errors.Add("- Mã sinh viên không được để trống.");
            if (string.IsNullOrWhiteSpace(sv.HoTen))
                result.Errors.Add("- Họ tên sinh viên không được để trống.");
            if (sv.NgaySinh > DateTime.Now.AddYears(-17))
                result.Errors.Add("- Sinh viên phải từ 17 tuổi trở lên.");
            if (!string.IsNullOrWhiteSpace(sv.Email) && !Regex.IsMatch(sv.Email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                result.Errors.Add("- Định dạng Email không hợp lệ.");
            if (string.IsNullOrWhiteSpace(sv.MaKhoa))
                result.Errors.Add("- Vui lòng chọn Khoa trực thuộc.");
            return result;
        }
    }
}
