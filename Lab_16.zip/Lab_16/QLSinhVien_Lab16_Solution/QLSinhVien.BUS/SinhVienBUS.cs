﻿using System;
using System.Collections.Generic;
using System.Data;
using QLSinhVien.DAL;
using QLSinhVien.DTO;

namespace QLSinhVien.BUS
{
    public class SinhVienBUS
    {
        private readonly SinhVienDAL _svDal = new SinhVienDAL();
        private readonly DangKyDAL _dkDal = new DangKyDAL();

        public List<SinhVienDTO> Search(string keyword, string maKhoa, int pageIndex, int pageSize, out int totalRecords)
        {
            return _svDal.Search(keyword, maKhoa, pageIndex, pageSize, out totalRecords);
        }

        public void Save(SinhVienDTO sv, bool isEditMode)
        {
            try
            {
                if (isEditMode) _svDal.Update(sv);
                else _svDal.Insert(sv);
                FileLogger.LogInfo($"{(isEditMode ? "Cập nhật" : "Thêm mới")} sinh viên {sv.MaSV}");
            }
            catch (Exception ex)
            {
                FileLogger.LogError("SinhVienBUS.Save", ex);
                throw;
            }
        }

        public void Delete(string maSV)
        {
            try
            {
                _svDal.Delete(maSV);
                FileLogger.LogInfo($"Xóa sinh viên {maSV}");
            }
            catch (Exception ex)
            {
                FileLogger.LogError("SinhVienBUS.Delete", ex);
                throw;
            }
        }

        public void RegisterStudentWithCourses(SinhVienDTO student, List<DangKyDTO> courses)
        {
            using (var conn = DbConnectionFactory.Create())
            {
                conn.Open();
                using (var tx = conn.BeginTransaction())
                {
                    try
                    {
                        _svDal.Insert(student, conn, tx);
                        foreach (var item in courses)
                        {
                            item.MaSV = student.MaSV;
                            _dkDal.Insert(item, conn, tx);
                        }
                        tx.Commit();
                        FileLogger.LogInfo($"Transaction thành công: Tạo SV {student.MaSV} với {courses.Count} học phần.");
                    }
                    catch (Exception ex)
                    {
                        tx.Rollback();
                        FileLogger.LogError("SinhVienBUS.RegisterStudentWithCourses (Rollback)", ex);
                        throw new Exception("Giao dịch thất bại, dữ liệu đã được hoàn tác (Rollback). Chi tiết: " + ex.Message);
                    }
                }
            }
        }

        public DataTable GetCoursesByStudent(string maSV) => _dkDal.GetBySinhVien(maSV);
    }
}
