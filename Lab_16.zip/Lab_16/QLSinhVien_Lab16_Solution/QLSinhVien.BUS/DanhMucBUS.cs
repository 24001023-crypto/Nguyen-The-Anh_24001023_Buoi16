﻿using System.Collections.Generic;
using QLSinhVien.DAL;
using QLSinhVien.DTO;

namespace QLSinhVien.BUS
{
    public class KhoaBUS
    {
        private readonly KhoaDAL _dal = new KhoaDAL();
        public List<KhoaDTO> GetAll() => _dal.GetAll();
        public void Save(KhoaDTO k, bool isEdit) => _dal.Save(k, isEdit);
        public void Delete(string maKhoa) => _dal.Delete(maKhoa);
    }

    public class HocPhanBUS
    {
        private readonly HocPhanDAL _dal = new HocPhanDAL();
        public List<HocPhanDTO> GetAll() => _dal.GetAll();
        public void Save(HocPhanDTO hp, bool isEdit) => _dal.Save(hp, isEdit);
        public void Delete(string maHP) => _dal.Delete(maHP);
    }
}
