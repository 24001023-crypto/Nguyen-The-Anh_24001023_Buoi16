﻿using System;
using System.IO;

namespace QLSinhVien.DAL
{
    public static class FileLogger
    {
        private static readonly string LogDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

        public static void LogError(string context, Exception ex)
        {
            try
            {
                if (!Directory.Exists(LogDir)) Directory.CreateDirectory(LogDir);
                string filePath = Path.Combine(LogDir, $"error_{DateTime.Now:yyyyMMdd}.log");
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [ERROR] [{context}] {ex.Message}{Environment.NewLine}{ex.StackTrace}{Environment.NewLine}--------------------------------------------------{Environment.NewLine}";
                File.AppendAllText(filePath, logEntry);
            }
            catch { }
        }

        public static void LogInfo(string message)
        {
            try
            {
                if (!Directory.Exists(LogDir)) Directory.CreateDirectory(LogDir);
                string filePath = Path.Combine(LogDir, $"app_{DateTime.Now:yyyyMMdd}.log");
                File.AppendAllText(filePath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [INFO] {message}{Environment.NewLine}");
            }
            catch { }
        }
    }
}
