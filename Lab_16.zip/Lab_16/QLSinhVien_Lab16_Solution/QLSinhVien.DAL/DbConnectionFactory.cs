﻿using System.Configuration;
using System.Data.SqlClient;

namespace QLSinhVien.DAL
{
    public static class DbConnectionFactory
    {
        public static SqlConnection Create()
        {
            string connStr = ConfigurationManager.ConnectionStrings["QLSinhVienConn"].ConnectionString;
            return new SqlConnection(connStr);
        }
    }
}
