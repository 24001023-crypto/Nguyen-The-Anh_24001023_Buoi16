﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using QLSinhVien.DTO;

namespace QLSinhVien.DAL
{
    public class KhoaDAL
    {
        public List<KhoaDTO> GetAll()
        {
            var list = new List<KhoaDTO>();
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("SELECT MaKhoa, TenKhoa, DienThoai FROM Khoa", conn))
            {
                conn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new KhoaDTO
                        {
                            MaKhoa = r["MaKhoa"].ToString(),
                            TenKhoa = r["TenKhoa"].ToString(),
                            DienThoai = r["DienThoai"]?.ToString()
                        });
                    }
                }
            }
            return list;
        }

        public void Save(KhoaDTO k, bool isEdit)
        {
            string sql = isEdit 
                ? "UPDATE Khoa SET TenKhoa = @Ten, DienThoai = @DT WHERE MaKhoa = @Ma"
                : "INSERT INTO Khoa(MaKhoa, TenKhoa, DienThoai) VALUES (@Ma, @Ten, @DT)";
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", k.MaKhoa);
                cmd.Parameters.AddWithValue("@Ten", k.TenKhoa);
                cmd.Parameters.AddWithValue("@DT", (object)k.DienThoai ?? DBNull.Value);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(string maKhoa)
        {
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("DELETE FROM Khoa WHERE MaKhoa = @Ma", conn))
            {
                cmd.Parameters.AddWithValue("@Ma", maKhoa);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public class HocPhanDAL
    {
        public List<HocPhanDTO> GetAll()
        {
            var list = new List<HocPhanDTO>();
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("SELECT MaHP, TenHP, SoTinChi, HocPhiTinChi FROM HocPhan", conn))
            {
                conn.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new HocPhanDTO
                        {
                            MaHP = r["MaHP"].ToString(),
                            TenHP = r["TenHP"].ToString(),
                            SoTinChi = Convert.ToInt32(r["SoTinChi"]),
                            HocPhiTinChi = Convert.ToDecimal(r["HocPhiTinChi"])
                        });
                    }
                }
            }
            return list;
        }

        public void Save(HocPhanDTO hp, bool isEdit)
        {
            string sql = isEdit 
                ? "UPDATE HocPhan SET TenHP = @Ten, SoTinChi = @TC, HocPhiTinChi = @HP WHERE MaHP = @Ma"
                : "INSERT INTO HocPhan(MaHP, TenHP, SoTinChi, HocPhiTinChi) VALUES (@Ma, @Ten, @TC, @HP)";
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@Ma", hp.MaHP);
                cmd.Parameters.AddWithValue("@Ten", hp.TenHP);
                cmd.Parameters.AddWithValue("@TC", hp.SoTinChi);
                cmd.Parameters.AddWithValue("@HP", hp.HocPhiTinChi);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(string maHP)
        {
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("DELETE FROM HocPhan WHERE MaHP = @Ma", conn))
            {
                cmd.Parameters.AddWithValue("@Ma", maHP);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
