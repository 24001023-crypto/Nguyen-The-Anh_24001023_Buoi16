﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using QLSinhVien.DTO;

namespace QLSinhVien.DAL
{
    public class SinhVienDAL
    {
        public List<SinhVienDTO> Search(string keyword, string maKhoa, int pageIndex, int pageSize, out int totalRecords)
        {
            totalRecords = 0;
            var list = new List<SinhVienDTO>();
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("sp_SinhVien_Search", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Keyword", (object)keyword ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@MaKhoa", (object)maKhoa ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@PageIndex", pageIndex);
                cmd.Parameters.AddWithValue("@PageSize", pageSize);

                conn.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if (totalRecords == 0) totalRecords = Convert.ToInt32(reader["TotalRecords"]);
                        list.Add(new SinhVienDTO
                        {
                            MaSV = reader["MaSV"].ToString(),
                            HoTen = reader["HoTen"].ToString(),
                            NgaySinh = Convert.ToDateTime(reader["NgaySinh"]),
                            GioiTinh = reader["GioiTinh"].ToString(),
                            Email = reader["Email"].ToString(),
                            MaKhoa = reader["MaKhoa"].ToString(),
                            TenKhoa = reader["TenKhoa"].ToString()
                        });
                    }
                }
            }
            return list;
        }

        public void Insert(SinhVienDTO sv, SqlConnection conn = null, SqlTransaction tx = null)
        {
            bool isExternalConn = (conn != null);
            if (!isExternalConn)
            {
                conn = DbConnectionFactory.Create();
                conn.Open();
            }

            try
            {
                using (var cmd = new SqlCommand("sp_SinhVien_Insert", conn, tx))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaSV", sv.MaSV);
                    cmd.Parameters.AddWithValue("@HoTen", sv.HoTen);
                    cmd.Parameters.AddWithValue("@NgaySinh", sv.NgaySinh);
                    cmd.Parameters.AddWithValue("@GioiTinh", sv.GioiTinh);
                    cmd.Parameters.AddWithValue("@Email", sv.Email);
                    cmd.Parameters.AddWithValue("@MaKhoa", sv.MaKhoa);
                    cmd.ExecuteNonQuery();
                }
            }
            finally
            {
                if (!isExternalConn && conn != null) conn.Dispose();
            }
        }

        public void Update(SinhVienDTO sv)
        {
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("sp_SinhVien_Update", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaSV", sv.MaSV);
                cmd.Parameters.AddWithValue("@HoTen", sv.HoTen);
                cmd.Parameters.AddWithValue("@NgaySinh", sv.NgaySinh);
                cmd.Parameters.AddWithValue("@GioiTinh", sv.GioiTinh);
                cmd.Parameters.AddWithValue("@Email", sv.Email);
                cmd.Parameters.AddWithValue("@MaKhoa", sv.MaKhoa);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void Delete(string maSV)
        {
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand("sp_SinhVien_Delete", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaSV", maSV);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }

    public class DangKyDAL
    {
        public void Insert(DangKyDTO dk, SqlConnection conn, SqlTransaction tx)
        {
            string sql = "INSERT INTO DangKy (MaSV, MaHP, HocKy, DiemTongKet) VALUES (@MaSV, @MaHP, @HocKy, @Diem)";
            using (var cmd = new SqlCommand(sql, conn, tx))
            {
                cmd.Parameters.AddWithValue("@MaSV", dk.MaSV);
                cmd.Parameters.AddWithValue("@MaHP", dk.MaHP);
                cmd.Parameters.AddWithValue("@HocKy", dk.HocKy);
                cmd.Parameters.AddWithValue("@Diem", (object)dk.DiemTongKet ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }

        public DataTable GetBySinhVien(string maSV)
        {
            var dt = new DataTable();
            string sql = @"SELECT dk.MaHP, hp.TenHP, hp.SoTinChi, dk.HocKy, dk.DiemTongKet 
                           FROM DangKy dk JOIN HocPhan hp ON dk.MaHP = hp.MaHP 
                           WHERE dk.MaSV = @MaSV";
            using (var conn = DbConnectionFactory.Create())
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@MaSV", maSV);
                using (var adapter = new SqlDataAdapter(cmd))
                {
                    adapter.Fill(dt);
                }
            }
            return dt;
        }
    }
}
