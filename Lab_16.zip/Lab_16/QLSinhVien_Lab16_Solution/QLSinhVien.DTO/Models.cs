﻿using System;

namespace QLSinhVien.DTO
{
    public class SinhVienDTO
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string GioiTinh { get; set; }
        public string Email { get; set; }
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }
    }

    public class KhoaDTO
    {
        public string MaKhoa { get; set; }
        public string TenKhoa { get; set; }
        public string DienThoai { get; set; }
    }

    public class HocPhanDTO
    {
        public string MaHP { get; set; }
        public string TenHP { get; set; }
        public int SoTinChi { get; set; }
        public decimal HocPhiTinChi { get; set; }
    }

    public class DangKyDTO
    {
        public string MaSV { get; set; }
        public string MaHP { get; set; }
        public string HocKy { get; set; }
        public double? DiemTongKet { get; set; }
    }
}
