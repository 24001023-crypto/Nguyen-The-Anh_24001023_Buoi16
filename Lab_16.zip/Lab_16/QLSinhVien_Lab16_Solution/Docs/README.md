# HỆ THỐNG QUẢN LÝ SINH VIÊN & ĐĂNG KÝ HỌC PHẦN (LAB 16 - IT3212)

## 1. Kiến trúc hệ thống
Ứng dụng WinForms (.NET Framework 4.8) xây dựng theo mô hình 3 lớp chuẩn:
- `QLSinhVien.DTO`: Đối tượng truyền dữ liệu (SinhVienDTO, KhoaDTO, HocPhanDTO, DangKyDTO).
- `QLSinhVien.DAL`: Truy xuất SQL Server qua ADO.NET, Stored Procedure tham số hóa, hỗ trợ Transaction và FileLogger bảo mật.
- `QLSinhVien.BUS`: Kiểm tra tính hợp lệ dữ liệu (Validator) và điều phối nghiệp vụ đa bảng.
- `QLSinhVien.GUI`: Giao diện đa Form MDI, Master-Detail, phân trang, xuất báo cáo.

## 2. Hướng dẫn cài đặt & Cấu hình
### Bước 1: Khởi tạo Cơ sở dữ liệu
1. Mở SQL Server Management Studio (SSMS).
2. Mở file `Database/QLSinhVien_Lab16.sql` và nhấn **Execute (F5)** để tạo CSDL `QLSinhVien_Lab16`, bảng, View, Stored Procedure và dữ liệu mẫu.

### Bước 2: Cấu hình chuỗi kết nối
Mở file `QLSinhVien.GUI/App.config` (hoặc `QLSinhVien.GUI.exe.config` sau khi build) và cập nhật `Server=` theo tên SQL Server trên máy:
```xml
<connectionStrings>
  <add name="QLSinhVienConn" 
       connectionString="Server=.;Database=QLSinhVien_Lab16;Trusted_Connection=True;TrustServerCertificate=True;" 
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

### Bước 3: Mở Solution và Chạy trên Visual Studio 2022
1. Mở file `QLSinhVien.sln` bằng Visual Studio 2022.
2. Chuột phải vào `QLSinhVien.GUI` chọn **Set as Startup Project**.
3. Nhấn **F5** để biên dịch và chạy ứng dụng.

## 3. Kịch bản kiểm thử bàn giao (Test Cases)

| ID | Chức năng | Thao tác thực hiện | Kết quả mong đợi | Trạng thái |
|---|---|---|---|---|
| **TC01** | Validation dữ liệu | Nhập tuổi SV < 17 hoặc Email sai định dạng, nhấn Lưu. | Hiển thị thông báo lỗi cụ thể, không gọi xuống DAL. | Đạt |
| **TC02** | Tìm kiếm & Phân trang | Nhập từ khóa "Thành", chọn Khoa CNTT, nhấn Lọc / Tìm. | Lọc đúng SV khớp điều kiện, cập nhật tổng số trang. | Đạt |
| **TC03** | Master-Detail | Click chọn SV001 trên lưới danh sách phía trên. | Lưới chi tiết phía dưới tự động hiển thị các học phần đã đăng ký. | Đạt |
| **TC04** | Transaction (Commit) | Nhập SV mới `SV010`, tích chọn 2 học phần, bỏ chọn Giả lập lỗi -> Lưu. | Cả bảng `SinhVien` và `DangKy` đều có dữ liệu `SV010`. | Đạt |
| **TC05** | Transaction (Rollback) | Nhập SV mới `SV011`, tích chọn ô *Giả lập lỗi khóa ngoại* -> Lưu. | Báo lỗi Rollback; kiểm tra SQL bảng `SinhVien` không tồn tại `SV011`. | Đạt |
| **TC06** | Báo cáo & Xuất file | Mở Báo cáo -> Nhấn Xuất Excel (.csv) hoặc Xuất Báo cáo In/PDF. | File xuất ra hiển thị đúng font tiếng Việt và đầy đủ số liệu. | Đạt |
| **TC07** | Logging bảo mật | Ngắt kết nối SQL Server, thử thao tác Lưu và mở thư mục `Logs/`. | Sinh file `error_yyyyMMdd.log` ghi chi tiết lỗi, không lộ ConnectionString. | Đạt |
