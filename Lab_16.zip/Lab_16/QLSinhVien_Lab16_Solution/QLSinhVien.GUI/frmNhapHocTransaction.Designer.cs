﻿namespace QLSinhVien.GUI
{
    partial class frmNhapHocTransaction
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtMaSV, txtHoTen, txtEmail, txtHocKy;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.ComboBox cboGioiTinh, cboKhoa;
        private System.Windows.Forms.CheckedListBox clbHocPhan;
        private System.Windows.Forms.CheckBox chkSimulateError;
        private System.Windows.Forms.Button btnLuuTransaction;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtMaSV = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(130, 20), Size = new System.Drawing.Size(220, 22) };
            this.txtHoTen = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(130, 55), Size = new System.Drawing.Size(220, 22) };
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker { Location = new System.Drawing.Point(130, 90), Format = System.Windows.Forms.DateTimePickerFormat.Short, Size = new System.Drawing.Size(220, 22) };
            this.cboGioiTinh = new System.Windows.Forms.ComboBox { Location = new System.Drawing.Point(130, 125), Size = new System.Drawing.Size(220, 24), DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList };
            this.cboGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
            this.txtEmail = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(130, 160), Size = new System.Drawing.Size(220, 22) };
            this.cboKhoa = new System.Windows.Forms.ComboBox { Location = new System.Drawing.Point(130, 195), Size = new System.Drawing.Size(220, 24), DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList };
            this.txtHocKy = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(130, 230), Size = new System.Drawing.Size(220, 22) };

            this.clbHocPhan = new System.Windows.Forms.CheckedListBox { Location = new System.Drawing.Point(390, 45), Size = new System.Drawing.Size(320, 180), CheckOnClick = true };
            this.chkSimulateError = new System.Windows.Forms.CheckBox { Text = "Giả lập lỗi khóa ngoại giữa chừng (Test Rollback)", Location = new System.Drawing.Point(390, 235), AutoSize = true, ForeColor = System.Drawing.Color.Red };
            this.btnLuuTransaction = new System.Windows.Forms.Button { Text = "Thực thi Transaction (Thêm SV + Đăng ký HP)", Location = new System.Drawing.Point(130, 280), Size = new System.Drawing.Size(320, 35) };
            this.btnLuuTransaction.Click += this.btnLuuTransaction_Click;

            this.ClientSize = new System.Drawing.Size(740, 350);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                new System.Windows.Forms.Label { Text = "Mã Sinh viên:", Location = new System.Drawing.Point(25, 23), AutoSize = true }, txtMaSV,
                new System.Windows.Forms.Label { Text = "Họ và tên:", Location = new System.Drawing.Point(25, 58), AutoSize = true }, txtHoTen,
                new System.Windows.Forms.Label { Text = "Ngày sinh:", Location = new System.Drawing.Point(25, 93), AutoSize = true }, dtpNgaySinh,
                new System.Windows.Forms.Label { Text = "Giới tính:", Location = new System.Drawing.Point(25, 128), AutoSize = true }, cboGioiTinh,
                new System.Windows.Forms.Label { Text = "Email:", Location = new System.Drawing.Point(25, 163), AutoSize = true }, txtEmail,
                new System.Windows.Forms.Label { Text = "Khoa:", Location = new System.Drawing.Point(25, 198), AutoSize = true }, cboKhoa,
                new System.Windows.Forms.Label { Text = "Học kỳ:", Location = new System.Drawing.Point(25, 233), AutoSize = true }, txtHocKy,
                new System.Windows.Forms.Label { Text = "Chọn danh sách Học phần đăng ký:", Location = new System.Drawing.Point(390, 20), AutoSize = true },
                clbHocPhan, chkSimulateError, btnLuuTransaction
            });
            this.Text = "Nghiệp vụ Nhập học & Đăng ký Tín chỉ (SqlTransaction)";
            this.Load += this.frmNhapHocTransaction_Load;
        }
    }
}
