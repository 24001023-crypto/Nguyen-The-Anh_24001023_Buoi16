﻿using System;
using System.Windows.Forms;

namespace QLSinhVien.GUI
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void mnuSinhVien_Click(object sender, EventArgs e)
        {
            var f = new frmSinhVien { MdiParent = this };
            f.Show();
        }

        private void mnuKhoaHocPhan_Click(object sender, EventArgs e)
        {
            var f = new frmDanhMuc { MdiParent = this };
            f.Show();
        }

        private void mnuNhapHocTx_Click(object sender, EventArgs e)
        {
            var f = new frmNhapHocTransaction { MdiParent = this };
            f.Show();
        }

        private void mnuBcSinhVien_Click(object sender, EventArgs e)
        {
            var f = new frmBaoCaoPreview(1) { MdiParent = this };
            f.Show();
        }

        private void mnuBcBangDiem_Click(object sender, EventArgs e)
        {
            var f = new frmBaoCaoPreview(2) { MdiParent = this };
            f.Show();
        }
    }
}
