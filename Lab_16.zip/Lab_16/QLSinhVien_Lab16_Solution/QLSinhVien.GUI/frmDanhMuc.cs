﻿using System;
using System.Linq;
using System.Windows.Forms;
using QLSinhVien.BUS;
using QLSinhVien.DTO;

namespace QLSinhVien.GUI
{
    public partial class frmDanhMuc : Form
    {
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        public frmDanhMuc()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            dgvKhoa.DataSource = _khoaBus.GetAll();
            dgvHocPhan.DataSource = _hpBus.GetAll();
        }

        private void btnLuuKhoa_Click(object sender, EventArgs e)
        {
            var list = _khoaBus.GetAll();
            bool isEdit = list.Any(x => x.MaKhoa.Equals(txtMaKhoa.Text.Trim(), StringComparison.OrdinalIgnoreCase));
            _khoaBus.Save(new KhoaDTO { MaKhoa = txtMaKhoa.Text.Trim(), TenKhoa = txtTenKhoa.Text.Trim(), DienThoai = txtDienThoai.Text.Trim() }, isEdit);
            LoadData();
        }

        private void btnXoaKhoa_Click(object sender, EventArgs e)
        {
            try { _khoaBus.Delete(txtMaKhoa.Text.Trim()); LoadData(); }
            catch (Exception ex) { MessageBox.Show("Lỗi xóa Khoa: " + ex.Message); }
        }

        private void btnLuuHP_Click(object sender, EventArgs e)
        {
            var list = _hpBus.GetAll();
            bool isEdit = list.Any(x => x.MaHP.Equals(txtMaHP.Text.Trim(), StringComparison.OrdinalIgnoreCase));
            _hpBus.Save(new HocPhanDTO
            {
                MaHP = txtMaHP.Text.Trim(),
                TenHP = txtTenHP.Text.Trim(),
                SoTinChi = int.Parse(txtSoTC.Text),
                HocPhiTinChi = decimal.Parse(txtHocPhi.Text)
            }, isEdit);
            LoadData();
        }

        private void btnXoaHP_Click(object sender, EventArgs e)
        {
            try { _hpBus.Delete(txtMaHP.Text.Trim()); LoadData(); }
            catch (Exception ex) { MessageBox.Show("Lỗi xóa Học phần: " + ex.Message); }
        }
    }
}
