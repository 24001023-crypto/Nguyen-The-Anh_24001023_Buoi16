﻿namespace QLSinhVien.GUI
{
    partial class frmBaoCaoPreview
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvBaoCao;
        private System.Windows.Forms.Button btnExportCsv, btnExportHtmlPdf;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnExportCsv = new System.Windows.Forms.Button { Text = "Xuất Excel (.csv)", Location = new System.Drawing.Point(20, 15), Size = new System.Drawing.Size(140, 30) };
            this.btnExportCsv.Click += this.btnExportCsv_Click;
            this.btnExportHtmlPdf = new System.Windows.Forms.Button { Text = "Xuất Báo cáo In / PDF (.html)", Location = new System.Drawing.Point(175, 15), Size = new System.Drawing.Size(190, 30) };
            this.btnExportHtmlPdf.Click += this.btnExportHtmlPdf_Click;

            this.dgvBaoCao = new System.Windows.Forms.DataGridView
            {
                Location = new System.Drawing.Point(20, 55),
                Size = new System.Drawing.Size(860, 420),
                ReadOnly = true,
                AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
            };

            this.ClientSize = new System.Drawing.Size(900, 500);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { btnExportCsv, btnExportHtmlPdf, dgvBaoCao });
            this.Text = "Xem trước & Xuất Báo cáo Thống kê";
            this.Load += this.frmBaoCaoPreview_Load;
        }
    }
}
