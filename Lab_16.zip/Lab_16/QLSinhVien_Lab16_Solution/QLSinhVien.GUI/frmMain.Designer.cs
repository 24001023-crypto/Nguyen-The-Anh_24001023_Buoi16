﻿namespace QLSinhVien.GUI
{
    partial class frmMain
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuDanhMuc;
        private System.Windows.Forms.ToolStripMenuItem mnuSinhVien;
        private System.Windows.Forms.ToolStripMenuItem mnuKhoaHocPhan;
        private System.Windows.Forms.ToolStripMenuItem mnuNghiepVu;
        private System.Windows.Forms.ToolStripMenuItem mnuNhapHocTx;
        private System.Windows.Forms.ToolStripMenuItem mnuBaoCao;
        private System.Windows.Forms.ToolStripMenuItem mnuBcSinhVien;
        private System.Windows.Forms.ToolStripMenuItem mnuBcBangDiem;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mnuDanhMuc = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSinhVien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuKhoaHocPhan = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNghiepVu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNhapHocTx = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBaoCao = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBcSinhVien = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBcBangDiem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();

            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuDanhMuc, this.mnuNghiepVu, this.mnuBaoCao
            });
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1100, 28);

            this.mnuDanhMuc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuSinhVien, this.mnuKhoaHocPhan
            });
            this.mnuDanhMuc.Text = "Quản lý Danh mục";

            this.mnuSinhVien.Text = "Quản lý Sinh viên (Master-Detail)";
            this.mnuSinhVien.Click += new System.EventHandler(this.mnuSinhVien_Click);

            this.mnuKhoaHocPhan.Text = "Quản lý Khoa && Học phần";
            this.mnuKhoaHocPhan.Click += new System.EventHandler(this.mnuKhoaHocPhan_Click);

            this.mnuNghiepVu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuNhapHocTx
            });
            this.mnuNghiepVu.Text = "Nghiệp vụ";

            this.mnuNhapHocTx.Text = "Nhập học && Đăng ký tín chỉ (Transaction)";
            this.mnuNhapHocTx.Click += new System.EventHandler(this.mnuNhapHocTx_Click);

            this.mnuBaoCao.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuBcSinhVien, this.mnuBcBangDiem
            });
            this.mnuBaoCao.Text = "Báo cáo && Thống kê";

            this.mnuBcSinhVien.Text = "Báo cáo Danh sách Sinh viên && Học phí";
            this.mnuBcSinhVien.Click += new System.EventHandler(this.mnuBcSinhVien_Click);

            this.mnuBcBangDiem.Text = "Báo cáo Bảng điểm Chi tiết";
            this.mnuBcBangDiem.Click += new System.EventHandler(this.mnuBcBangDiem_Click);

            this.ClientSize = new System.Drawing.Size(1100, 680);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HỆ THỐNG QUẢN LÝ SINH VIÊN - LAB 16 (3-LAYER + TRANSACTION)";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
