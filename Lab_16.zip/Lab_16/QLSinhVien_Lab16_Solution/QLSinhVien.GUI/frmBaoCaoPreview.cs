﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Windows.Forms;
using QLSinhVien.DAL;

namespace QLSinhVien.GUI
{
    public partial class frmBaoCaoPreview : Form
    {
        private readonly int _reportType;
        private DataTable _dtReport = new DataTable();

        public frmBaoCaoPreview(int reportType)
        {
            _reportType = reportType;
            InitializeComponent();
        }

        private void frmBaoCaoPreview_Load(object sender, EventArgs e)
        {
            try
            {
                using (var conn = DbConnectionFactory.Create())
                {
                    string sql = _reportType == 1 ? "SELECT * FROM vw_BaoCaoSinhVien" : "SELECT * FROM vw_BangDiemChiTiet";
                    using (var cmd = new SqlCommand(sql, conn))
                    {
                        new SqlDataAdapter(cmd).Fill(_dtReport);
                    }
                }
                dgvBaoCao.DataSource = _dtReport;
                this.Text = _reportType == 1 ? "Báo cáo 1: Thống kê Sinh viên & Học phí theo Khoa" : "Báo cáo 2: Bảng điểm Chi tiết Học phần";
            }
            catch (Exception ex)
            {
                FileLogger.LogError("frmBaoCaoPreview_Load", ex);
                MessageBox.Show("Lỗi tải dữ liệu báo cáo: " + ex.Message);
            }
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog { Filter = "Excel CSV|*.csv", FileName = $"BaoCao_{_reportType}_{DateTime.Now:yyyyMMdd}.csv" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    var sb = new StringBuilder();
                    for (int i = 0; i < _dtReport.Columns.Count; i++)
                        sb.Append(_dtReport.Columns[i].ColumnName + (i < _dtReport.Columns.Count - 1 ? "," : ""));
                    sb.AppendLine();

                    foreach (DataRow row in _dtReport.Rows)
                    {
                        for (int i = 0; i < _dtReport.Columns.Count; i++)
                            sb.Append($""{row[i]}"" + (i < _dtReport.Columns.Count - 1 ? "," : ""));
                        sb.AppendLine();
                    }
                    File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                    MessageBox.Show("Xuất Excel (.csv) thành công!");
                }
            }
        }

        private void btnExportHtmlPdf_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog { Filter = "HTML Print/PDF|*.html", FileName = $"BaoCao_{_reportType}_{DateTime.Now:yyyyMMdd}.html" })
            {
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    var sb = new StringBuilder("<html><head><meta charset='utf-8'><style>table{border-collapse:collapse;width:100%;font-family:Arial}th,td{border:1px solid #333;padding:8px;text-align:left}th{background:#f2f2f2}</style></head><body>");
                    sb.Append($"<h2>{this.Text}</h2><table><tr>");
                    foreach (DataColumn col in _dtReport.Columns) sb.Append($"<th>{col.ColumnName}</th>");
                    sb.Append("</tr>");
                    foreach (DataRow row in _dtReport.Rows)
                    {
                        sb.Append("<tr>");
                        foreach (var item in row.ItemArray) sb.Append($"<td>{item}</td>");
                        sb.Append("</tr>");
                    }
                    sb.Append("</table><script>window.print();</script></body></html>");
                    File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                    System.Diagnostics.Process.Start(sfd.FileName);
                }
            }
        }
    }
}
