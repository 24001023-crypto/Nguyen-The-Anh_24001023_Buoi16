﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using QLSinhVien.BUS;
using QLSinhVien.DTO;

namespace QLSinhVien.GUI
{
    public partial class frmSinhVien : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        
        private bool _editMode = false;
        private int _pageIndex = 1;
        private readonly int _pageSize = 10;
        private int _totalRecords = 0;

        public frmSinhVien()
        {
            InitializeComponent();
        }

        private void frmSinhVien_Load(object sender, EventArgs e)
        {
            LoadComboBoxKhoa();
            cboGioiTinh.SelectedIndex = 0;
            LoadGridSinhVien();
            SetControlState(false);
        }

        private void LoadComboBoxKhoa()
        {
            var listKhoa = _khoaBus.GetAll();
            cboKhoa.DataSource = new List<KhoaDTO>(listKhoa);
            cboKhoa.DisplayMember = "TenKhoa";
            cboKhoa.ValueMember = "MaKhoa";

            var filterList = new List<KhoaDTO> { new KhoaDTO { MaKhoa = "", TenKhoa = "-- Tất cả Khoa --" } };
            filterList.AddRange(listKhoa);
            cboFilterKhoa.DataSource = filterList;
            cboFilterKhoa.DisplayMember = "TenKhoa";
            cboFilterKhoa.ValueMember = "MaKhoa";
        }

        private void LoadGridSinhVien()
        {
            string keyword = txtSearch.Text.Trim();
            string maKhoa = cboFilterKhoa.SelectedValue?.ToString() ?? "";

            var data = _svBus.Search(keyword, maKhoa, _pageIndex, _pageSize, out _totalRecords);
            dgvSinhVien.DataSource = data;

            int totalPages = (int)Math.Ceiling((double)_totalRecords / _pageSize);
            if (totalPages == 0) totalPages = 1;
            lblPageInfo.Text = $"Trang {_pageIndex}/{totalPages} (Tổng: {_totalRecords} SV)";
            btnPrev.Enabled = _pageIndex > 1;
            btnNext.Enabled = _pageIndex < totalPages;
        }

        private void dgvSinhVien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null || dgvSinhVien.CurrentRow.DataBoundItem == null) return;

            var sv = (SinhVienDTO)dgvSinhVien.CurrentRow.DataBoundItem;
            txtMaSV.Text = sv.MaSV;
            txtHoTen.Text = sv.HoTen;
            dtpNgaySinh.Value = sv.NgaySinh;
            cboGioiTinh.Text = sv.GioiTinh;
            txtEmail.Text = sv.Email;
            cboKhoa.SelectedValue = sv.MaKhoa;

            dgvChiTietDangKy.DataSource = _svBus.GetCoursesByStudent(sv.MaSV);
        }

        private void SetControlState(bool isEditing)
        {
            txtMaSV.Enabled = isEditing && !_editMode;
            txtHoTen.Enabled = isEditing;
            dtpNgaySinh.Enabled = isEditing;
            cboGioiTinh.Enabled = isEditing;
            txtEmail.Enabled = isEditing;
            cboKhoa.Enabled = isEditing;
            btnLuu.Enabled = isEditing;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            _editMode = false;
            ClearForm();
            SetControlState(true);
            txtMaSV.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaSV.Text)) return;
            _editMode = true;
            SetControlState(true);
            txtHoTen.Focus();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            var dto = new SinhVienDTO
            {
                MaSV = txtMaSV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                NgaySinh = dtpNgaySinh.Value.Date,
                GioiTinh = cboGioiTinh.Text,
                Email = txtEmail.Text.Trim(),
                MaKhoa = cboKhoa.SelectedValue?.ToString()
            };

            var validation = SinhVienValidator.Validate(dto);
            if (!validation.IsValid)
            {
                MessageBox.Show(string.Join(Environment.NewLine, validation.Errors), "Dữ liệu không hợp lệ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _svBus.Save(dto, _editMode);
                MessageBox.Show("Lưu dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadGridSinhVien();
                SetControlState(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hệ thống: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaSV.Text)) return;
            if (MessageBox.Show($"Bạn có chắc muốn xóa sinh viên {txtMaSV.Text}?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    _svBus.Delete(txtMaSV.Text.Trim());
                    LoadGridSinhVien();
                    ClearForm();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể xóa: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ClearForm()
        {
            txtMaSV.Clear();
            txtHoTen.Clear();
            txtEmail.Clear();
            dtpNgaySinh.Value = new DateTime(2006, 1, 1);
            cboGioiTinh.SelectedIndex = 0;
        }

        private void btnTimKiem_Click(object sender, EventArgs e) { _pageIndex = 1; LoadGridSinhVien(); }
        private void btnPrev_Click(object sender, EventArgs e) { if (_pageIndex > 1) { _pageIndex--; LoadGridSinhVien(); } }
        private void btnNext_Click(object sender, EventArgs e) { _pageIndex++; LoadGridSinhVien(); }
    }
}
