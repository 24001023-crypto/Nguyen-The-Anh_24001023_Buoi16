﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using QLSinhVien.BUS;
using QLSinhVien.DTO;

namespace QLSinhVien.GUI
{
    public partial class frmNhapHocTransaction : Form
    {
        private readonly SinhVienBUS _svBus = new SinhVienBUS();
        private readonly KhoaBUS _khoaBus = new KhoaBUS();
        private readonly HocPhanBUS _hpBus = new HocPhanBUS();

        public frmNhapHocTransaction()
        {
            InitializeComponent();
        }

        private void frmNhapHocTransaction_Load(object sender, EventArgs e)
        {
            cboKhoa.DataSource = _khoaBus.GetAll();
            cboKhoa.DisplayMember = "TenKhoa";
            cboKhoa.ValueMember = "MaKhoa";
            cboGioiTinh.SelectedIndex = 0;
            txtHocKy.Text = "2026-1";

            clbHocPhan.DataSource = _hpBus.GetAll();
            clbHocPhan.DisplayMember = "TenHP";
            clbHocPhan.ValueMember = "MaHP";
        }

        private void btnLuuTransaction_Click(object sender, EventArgs e)
        {
            var sv = new SinhVienDTO
            {
                MaSV = txtMaSV.Text.Trim(),
                HoTen = txtHoTen.Text.Trim(),
                NgaySinh = dtpNgaySinh.Value.Date,
                GioiTinh = cboGioiTinh.Text,
                Email = txtEmail.Text.Trim(),
                MaKhoa = cboKhoa.SelectedValue?.ToString()
            };

            var valid = SinhVienValidator.Validate(sv);
            if (!valid.IsValid)
            {
                MessageBox.Show(string.Join(Environment.NewLine, valid.Errors));
                return;
            }

            var selectedCourses = new List<DangKyDTO>();
            foreach (HocPhanDTO item in clbHocPhan.CheckedItems)
            {
                selectedCourses.Add(new DangKyDTO
                {
                    MaSV = sv.MaSV,
                    MaHP = item.MaHP,
                    HocKy = txtHocKy.Text.Trim(),
                    DiemTongKet = null
                });
            }

            if (chkSimulateError.Checked)
            {
                selectedCourses.Add(new DangKyDTO
                {
                    MaSV = sv.MaSV,
                    MaHP = "MA_HP_KHONG_TON_TAI_999",
                    HocKy = txtHocKy.Text.Trim()
                });
            }

            try
            {
                _svBus.RegisterStudentWithCourses(sv, selectedCourses);
                MessageBox.Show("COMMIT THÀNH CÔNG: Đã tạo sinh viên và đăng ký toàn bộ học phần!", "Transaction Thành Công", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ROLLBACK ĐÃ KÍCH HOẠT", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
