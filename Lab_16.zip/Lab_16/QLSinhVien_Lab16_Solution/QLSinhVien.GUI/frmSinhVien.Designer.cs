﻿namespace QLSinhVien.GUI
{
    partial class frmSinhVien
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtMaSV, txtHoTen, txtEmail, txtSearch;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.ComboBox cboGioiTinh, cboKhoa, cboFilterKhoa;
        private System.Windows.Forms.Button btnThem, btnSua, btnLuu, btnXoa, btnTimKiem, btnPrev, btnNext;
        private System.Windows.Forms.Label lblPageInfo;
        private System.Windows.Forms.DataGridView dgvSinhVien, dgvChiTietDangKy;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtMaSV = new System.Windows.Forms.TextBox();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.cboGioiTinh = new System.Windows.Forms.ComboBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.cboKhoa = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.cboFilterKhoa = new System.Windows.Forms.ComboBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.dgvSinhVien = new System.Windows.Forms.DataGridView();
            this.dgvChiTietDangKy = new System.Windows.Forms.DataGridView();
            this.btnPrev = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.lblPageInfo = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // Labels & Inputs
            var l1 = new System.Windows.Forms.Label { Text = "Mã SV:", Location = new System.Drawing.Point(20, 20), AutoSize = true };
            this.txtMaSV.Location = new System.Drawing.Point(95, 17); this.txtMaSV.Size = new System.Drawing.Size(150, 22);

            var l2 = new System.Windows.Forms.Label { Text = "Họ tên:", Location = new System.Drawing.Point(270, 20), AutoSize = true };
            this.txtHoTen.Location = new System.Drawing.Point(335, 17); this.txtHoTen.Size = new System.Drawing.Size(200, 22);

            var l3 = new System.Windows.Forms.Label { Text = "Ngày sinh:", Location = new System.Drawing.Point(560, 20), AutoSize = true };
            this.dtpNgaySinh.Location = new System.Drawing.Point(635, 17); this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short; this.dtpNgaySinh.Size = new System.Drawing.Size(120, 22);

            var l4 = new System.Windows.Forms.Label { Text = "Giới tính:", Location = new System.Drawing.Point(20, 55), AutoSize = true };
            this.cboGioiTinh.Location = new System.Drawing.Point(95, 52); this.cboGioiTinh.Size = new System.Drawing.Size(150, 24);
            this.cboGioiTinh.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboGioiTinh.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });

            var l5 = new System.Windows.Forms.Label { Text = "Email:", Location = new System.Drawing.Point(270, 55), AutoSize = true };
            this.txtEmail.Location = new System.Drawing.Point(335, 52); this.txtEmail.Size = new System.Drawing.Size(200, 22);

            var l6 = new System.Windows.Forms.Label { Text = "Khoa:", Location = new System.Drawing.Point(560, 55), AutoSize = true };
            this.cboKhoa.Location = new System.Drawing.Point(635, 52); this.cboKhoa.Size = new System.Drawing.Size(180, 24);
            this.cboKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // CRUD Buttons
            this.btnThem.Text = "Thêm mới"; this.btnThem.Location = new System.Drawing.Point(20, 90); this.btnThem.Click += this.btnThem_Click;
            this.btnSua.Text = "Sửa"; this.btnSua.Location = new System.Drawing.Point(105, 90); this.btnSua.Click += this.btnSua_Click;
            this.btnLuu.Text = "Lưu"; this.btnLuu.Location = new System.Drawing.Point(190, 90); this.btnLuu.Click += this.btnLuu_Click;
            this.btnXoa.Text = "Xóa"; this.btnXoa.Location = new System.Drawing.Point(275, 90); this.btnXoa.Click += this.btnXoa_Click;

            // Search bar
            var l7 = new System.Windows.Forms.Label { Text = "Tìm kiếm:", Location = new System.Drawing.Point(400, 95), AutoSize = true };
            this.txtSearch.Location = new System.Drawing.Point(465, 91); this.txtSearch.Size = new System.Drawing.Size(160, 22);
            this.cboFilterKhoa.Location = new System.Drawing.Point(635, 90); this.cboFilterKhoa.Size = new System.Drawing.Size(160, 24);
            this.cboFilterKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.btnTimKiem.Text = "Lọc / Tìm"; this.btnTimKiem.Location = new System.Drawing.Point(805, 90); this.btnTimKiem.Click += this.btnTimKiem_Click;

            // Master Grid
            this.dgvSinhVien.Location = new System.Drawing.Point(20, 130);
            this.dgvSinhVien.Size = new System.Drawing.Size(960, 220);
            this.dgvSinhVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSinhVien.ReadOnly = true;
            this.dgvSinhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSinhVien.SelectionChanged += this.dgvSinhVien_SelectionChanged;

            // Paging
            this.btnPrev.Text = "< Trước"; this.btnPrev.Location = new System.Drawing.Point(20, 358); this.btnPrev.Click += this.btnPrev_Click;
            this.lblPageInfo.Text = "Trang 1/1"; this.lblPageInfo.Location = new System.Drawing.Point(110, 363); this.lblPageInfo.AutoSize = true;
            this.btnNext.Text = "Sau >"; this.btnNext.Location = new System.Drawing.Point(280, 358); this.btnNext.Click += this.btnNext_Click;

            // Detail Grid
            var lDetail = new System.Windows.Forms.Label { Text = "Chi tiết Học phần đã đăng ký của Sinh viên đang chọn (Detail):", Location = new System.Drawing.Point(20, 395), AutoSize = true };
            this.dgvChiTietDangKy.Location = new System.Drawing.Point(20, 418);
            this.dgvChiTietDangKy.Size = new System.Drawing.Size(960, 160);
            this.dgvChiTietDangKy.ReadOnly = true;
            this.dgvChiTietDangKy.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.ClientSize = new System.Drawing.Size(1010, 600);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                l1, txtMaSV, l2, txtHoTen, l3, dtpNgaySinh, l4, cboGioiTinh, l5, txtEmail, l6, cboKhoa,
                btnThem, btnSua, btnLuu, btnXoa, l7, txtSearch, cboFilterKhoa, btnTimKiem,
                dgvSinhVien, btnPrev, lblPageInfo, btnNext, lDetail, dgvChiTietDangKy
            });
            this.Text = "Quản lý Sinh viên (CRUD - Phân trang - Master/Detail)";
            this.Load += new System.EventHandler(this.frmSinhVien_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
