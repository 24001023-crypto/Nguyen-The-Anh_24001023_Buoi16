﻿namespace QLSinhVien.GUI
{
    partial class frmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabKhoa, tabHocPhan;
        private System.Windows.Forms.TextBox txtMaKhoa, txtTenKhoa, txtDienThoai;
        private System.Windows.Forms.Button btnLuuKhoa, btnXoaKhoa;
        private System.Windows.Forms.DataGridView dgvKhoa;
        private System.Windows.Forms.TextBox txtMaHP, txtTenHP, txtSoTC, txtHocPhi;
        private System.Windows.Forms.Button btnLuuHP, btnXoaHP;
        private System.Windows.Forms.DataGridView dgvHocPhan;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl { Location = new System.Drawing.Point(12, 12), Size = new System.Drawing.Size(760, 440) };
            this.tabKhoa = new System.Windows.Forms.TabPage { Text = "Danh mục Khoa" };
            this.tabHocPhan = new System.Windows.Forms.TabPage { Text = "Danh mục Học phần" };

            // Khoa controls
            var lk1 = new System.Windows.Forms.Label { Text = "Mã Khoa:", Location = new System.Drawing.Point(20, 20), AutoSize = true };
            this.txtMaKhoa = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(95, 17), Size = new System.Drawing.Size(120, 22) };
            var lk2 = new System.Windows.Forms.Label { Text = "Tên Khoa:", Location = new System.Drawing.Point(235, 20), AutoSize = true };
            this.txtTenKhoa = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(310, 17), Size = new System.Drawing.Size(200, 22) };
            var lk3 = new System.Windows.Forms.Label { Text = "Điện thoại:", Location = new System.Drawing.Point(525, 20), AutoSize = true };
            this.txtDienThoai = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(600, 17), Size = new System.Drawing.Size(120, 22) };
            this.btnLuuKhoa = new System.Windows.Forms.Button { Text = "Lưu Khoa", Location = new System.Drawing.Point(20, 55) };
            this.btnLuuKhoa.Click += this.btnLuuKhoa_Click;
            this.btnXoaKhoa = new System.Windows.Forms.Button { Text = "Xóa Khoa", Location = new System.Drawing.Point(110, 55) };
            this.btnXoaKhoa.Click += this.btnXoaKhoa_Click;
            this.dgvKhoa = new System.Windows.Forms.DataGridView { Location = new System.Drawing.Point(20, 95), Size = new System.Drawing.Size(700, 290), ReadOnly = true, AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill };
            this.dgvKhoa.SelectionChanged += (s, e) => {
                if (dgvKhoa.CurrentRow?.DataBoundItem is DTO.KhoaDTO k) { txtMaKhoa.Text = k.MaKhoa; txtTenKhoa.Text = k.TenKhoa; txtDienThoai.Text = k.DienThoai; }
            };
            this.tabKhoa.Controls.AddRange(new System.Windows.Forms.Control[] { lk1, txtMaKhoa, lk2, txtTenKhoa, lk3, txtDienThoai, btnLuuKhoa, btnXoaKhoa, dgvKhoa });

            // HocPhan controls
            var lh1 = new System.Windows.Forms.Label { Text = "Mã HP:", Location = new System.Drawing.Point(20, 20), AutoSize = true };
            this.txtMaHP = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(80, 17), Size = new System.Drawing.Size(100, 22) };
            var lh2 = new System.Windows.Forms.Label { Text = "Tên HP:", Location = new System.Drawing.Point(195, 20), AutoSize = true };
            this.txtTenHP = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(255, 17), Size = new System.Drawing.Size(180, 22) };
            var lh3 = new System.Windows.Forms.Label { Text = "Số TC:", Location = new System.Drawing.Point(450, 20), AutoSize = true };
            this.txtSoTC = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(500, 17), Size = new System.Drawing.Size(50, 22) };
            var lh4 = new System.Windows.Forms.Label { Text = "Học phí/TC:", Location = new System.Drawing.Point(560, 20), AutoSize = true };
            this.txtHocPhi = new System.Windows.Forms.TextBox { Location = new System.Drawing.Point(640, 17), Size = new System.Drawing.Size(80, 22) };
            this.btnLuuHP = new System.Windows.Forms.Button { Text = "Lưu Học phần", Location = new System.Drawing.Point(20, 55), Size = new System.Drawing.Size(100, 25) };
            this.btnLuuHP.Click += this.btnLuuHP_Click;
            this.btnXoaHP = new System.Windows.Forms.Button { Text = "Xóa Học phần", Location = new System.Drawing.Point(130, 55), Size = new System.Drawing.Size(100, 25) };
            this.btnXoaHP.Click += this.btnXoaHP_Click;
            this.dgvHocPhan = new System.Windows.Forms.DataGridView { Location = new System.Drawing.Point(20, 95), Size = new System.Drawing.Size(700, 290), ReadOnly = true, AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill };
            this.dgvHocPhan.SelectionChanged += (s, e) => {
                if (dgvHocPhan.CurrentRow?.DataBoundItem is DTO.HocPhanDTO hp) { txtMaHP.Text = hp.MaHP; txtTenHP.Text = hp.TenHP; txtSoTC.Text = hp.SoTinChi.ToString(); txtHocPhi.Text = hp.HocPhiTinChi.ToString(); }
            };
            this.tabHocPhan.Controls.AddRange(new System.Windows.Forms.Control[] { lh1, txtMaHP, lh2, txtTenHP, lh3, txtSoTC, lh4, txtHocPhi, btnLuuHP, btnXoaHP, dgvHocPhan });

            this.tabControl1.TabPages.Add(this.tabKhoa);
            this.tabControl1.TabPages.Add(this.tabHocPhan);
            this.ClientSize = new System.Drawing.Size(784, 464);
            this.Controls.Add(this.tabControl1);
            this.Text = "Quản lý Danh mục Khoa & Học phần";
            this.Load += (s, e) => { LoadData(); };
        }
    }
}
